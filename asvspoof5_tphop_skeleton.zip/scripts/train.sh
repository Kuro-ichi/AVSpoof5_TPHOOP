#!/usr/bin/env bash
python -m src.train --config configs/default.yaml
